from fastapi import APIRouter

from flowforge.api.routes import auth, health, platform, tenants

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(platform.router)
api_router.include_router(tenants.router)
