$ErrorActionPreference="Stop";Set-Location (Split-Path -Parent $PSScriptRoot);$P=".\.venv\Scripts\python.exe"
& $P -m ruff check src/flowforge/phase1a tests/phase1a;if($LASTEXITCODE-ne 0){throw "Ruff failed"}
& $P -m ruff format --check src/flowforge/phase1a tests/phase1a;if($LASTEXITCODE-ne 0){throw "Format failed"}
& $P -m mypy src/flowforge/phase1a;if($LASTEXITCODE-ne 0){throw "MyPy failed"}
& $P -m pytest -q tests/phase1a;if($LASTEXITCODE-ne 0){throw "Tests failed"}
Write-Host "PHASE 1A VERIFICATION PASSED" -ForegroundColor Green
