$ErrorActionPreference="Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$P=".\.venv\Scripts\python.exe"
$M=".\src\flowforge\main.py"
$T=[IO.File]::ReadAllText((Resolve-Path $M))
$I="from flowforge.phase4a_stage3.router import router as phase4a_stage3_router"
if(-not $T.Contains($I)){$T=$T.Replace("from flowforge.api.router import api_router","from flowforge.api.router import api_router`r`n$I")}
if(-not $T.Contains("app.include_router(phase4a_stage3_router)")){$T+="`r`napp.include_router(phase4a_stage3_router)`r`n"}
[IO.File]::WriteAllText((Resolve-Path $M),$T,[Text.UTF8Encoding]::new($false))
$E=".\migrations\env.py"
$X=[IO.File]::ReadAllText((Resolve-Path $E))
$J="from flowforge.phase4a_stage3 import models as phase4a_stage3_models  # noqa: F401"
if(-not $X.Contains($J)){$X=$J+"`r`n"+$X}
[IO.File]::WriteAllText((Resolve-Path $E),$X,[Text.UTF8Encoding]::new($false))
& $P -m ruff check src/flowforge/phase4a_stage3 tests/phase4a_stage3 src/flowforge/main.py migrations/env.py --fix
if($LASTEXITCODE-ne 0){throw "Ruff failed"}
& $P -m ruff format src/flowforge/phase4a_stage3 tests/phase4a_stage3 src/flowforge/main.py migrations/env.py
& $P -m alembic revision --autogenerate -m "phase 4a stage 3 payroll calculation posting"
if($LASTEXITCODE-ne 0){throw "Migration failed"}
& $P -m alembic upgrade head
if($LASTEXITCODE-ne 0){throw "Upgrade failed"}
& ".\scripts\Verify-Phase4A-Stage3.ps1"
